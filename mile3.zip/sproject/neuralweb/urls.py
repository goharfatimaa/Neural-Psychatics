from django.urls import path,include

from . import views
from rest_framework import routers


app_name = 'neuralweb'
urlpatterns = [
     
      path('', views.index, name='index'),
      path('<int:Blog_pk>/', views.detail, name='detail'),
      path("getblogs/",views.getBlog,name='getBlog'),
      path("aboutus/",views.AboutUs,name='AboutUs'),
      
      #path('quiz/', views.quiz, name='Quiz'),
      #path('vote/', views.vote, name='vote'),
      #path('result/', views.vote, name='result'),
      


   ## path('<slug:slug>/', views.PostDetail.as_view(), name='post_detail')
    
]