from django.contrib import admin

# Register your models here.
from .models import Blog, Question,Choice
 
admin.site.register(Blog)
admin.site.register(Question)
admin.site.register(Choice)