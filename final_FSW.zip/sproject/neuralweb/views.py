from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse 
from django.views import generic
from django.template import loader
from django.http import JsonResponse
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.renderers import TemplateHTMLRenderer
from rest_framework.response import Response
from django.core import serializers
from .serializers import BlogSerializer
from .models import Blog,Quiz
import requests
from django.contrib.auth import authenticate, login


def getBlog(request): #apicalling 
    queryset = Blog.objects.filter(status=1).order_by('-posted')
    data = serializers.serialize('json', queryset)
    return HttpResponse(data, content_type="application/json")

def detail(request,Blog_pk):
      Blog_body = get_object_or_404(Blog, pk=Blog_pk)
      return render(request, 'post_detail.html', {'Blog': Blog_body})      

# Create your views here.
def index(request):
    r=requests.get('http://127.0.0.1:8000/getblogs/')
    queryset = r.json()
    #queryset = Blog.objects.filter(status=1).order_by('-posted')
    template = loader.get_template('index.html')
    context = {
        'queryset': queryset,
    }
    return HttpResponse(template.render(context, request))
    
def AboutUs(request):
      return render(request, 'AboutUs.html')

#def login(request):
   
def quiz(request):
    questions = Quiz.objects.all()
    return render(request, 'quiz.html', { 'questions': questions})
def covid(request):
    return render(request, 'covid.html')





