from django.db import models
STATUS = (
    (0,"Draft"),
    (1,"Publish")
)

# Create your models here.
class Blog(models.Model):
  title = models.CharField(max_length=100, unique=True)
  slug = models.SlugField(max_length=100, unique=True)
  body = models.TextField()
  desc=models.CharField(max_length=50, unique=True, default='SOME STRING') 
  status = models.IntegerField(choices=STATUS, default=0)
  posted = models.DateField(db_index=True, auto_now_add=True)



class Meta:
        ordering = ['-posted']

def __str__(self):
   return self.title
class Quiz(models.Model):
	question = models.CharField(max_length = 500)
	option1 = models.CharField(max_length = 20)
	option2 = models.CharField(max_length = 20)
	option3 = models.CharField(max_length = 20)
	option4 = models.CharField(max_length = 20)
	answer = models.CharField(max_length = 20)
