from django.urls import path,include
from . import views
from rest_framework import routers

app_name = 'neuralweb'
urlpatterns = [
     
      path('', views.index, name='index'),
      path('<int:Blog_pk>/', views.detail, name='detail'),
      path("getblogs/",views.getBlog,name='getBlog'),
      path("aboutus/",views.AboutUs,name='AboutUs'),
      path("quiz/", views.quiz, name='quiz'),
      path("covid/", views.covid, name='covid'),
      #path('accounts/', include('django.contrib.auth.urls')),
      #path("login/",views.login,name='login'),
      
      
      #path('vote/', views.vote, name='vote'),
      #path('result/', views.vote, name='result'),
      


   ## path('<slug:slug>/', views.PostDetail.as_view(), name='post_detail')
    
]
